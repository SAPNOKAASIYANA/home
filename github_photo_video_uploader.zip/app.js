// Firebase Photo & Video uploader
// IMPORTANT: Replace Firebase config below before hosting on GitHub Pages

import { initializeApp } from "https://www.gstatic.com/firebasejs/9.23.0/firebase-app.js";
import { getAuth, GoogleAuthProvider, signInWithPopup, signOut, onAuthStateChanged } from "https://www.gstatic.com/firebasejs/9.23.0/firebase-auth.js";
import { getFirestore, collection, addDoc, onSnapshot, updateDoc, doc, arrayUnion, serverTimestamp } from "https://www.gstatic.com/firebasejs/9.23.0/firebase-firestore.js";
import { getStorage, ref, uploadBytesResumable, getDownloadURL } from "https://www.gstatic.com/firebasejs/9.23.0/firebase-storage.js";

const firebaseConfig = {
  apiKey: "REPLACE_API_KEY",
  authDomain: "REPLACE_AUTH_DOMAIN",
  projectId: "REPLACE_PROJECT_ID",
  storageBucket: "REPLACE_STORAGE_BUCKET",
  messagingSenderId: "REPLACE_SENDER_ID",
  appId: "REPLACE_APP_ID"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const provider = new GoogleAuthProvider();
const db = getFirestore(app);
const storage = getStorage(app);

const loginBtn = document.getElementById('login-btn');
const logoutBtn = document.getElementById('logout-btn');
const userArea = document.getElementById('user-area');
const uploader = document.getElementById('uploader');
const uploadBtn = document.getElementById('upload-btn');
const mediaFile = document.getElementById('media-file');
const captionInput = document.getElementById('caption');
const uploadStatus = document.getElementById('upload-status');
const postsEl = document.getElementById('posts');

let currentUser = null;

loginBtn.onclick = async () => {
  await signInWithPopup(auth, provider);
};

logoutBtn.onclick = async () => {
  await signOut(auth);
};

onAuthStateChanged(auth, user => {
  currentUser = user;
  if(user){
    userArea.innerHTML = `<img src="${user.photoURL}" class="avatar"> ${user.displayName}`;
    uploader.style.display = 'block';
  } else {
    userArea.innerHTML = '<button id="login-btn">Sign in with Google</button>';
    uploader.style.display = 'none';
  }
});

uploadBtn.onclick = async () => {
  if(!currentUser){alert('कृपया पहले लॉगिन करें');return;}
  const file = mediaFile.files[0];
  if(!file){alert('फाइल चुनें');return;}
  uploadStatus.textContent = 'Uploading...';
  const fileRef = ref(storage, `posts/${currentUser.uid}/${file.name}`);
  const uploadTask = uploadBytesResumable(fileRef, file);
  uploadTask.on('state_changed', null, err => {
    uploadStatus.textContent = 'Error: '+err.message;
  }, async () => {
    const url = await getDownloadURL(uploadTask.snapshot.ref);
    await addDoc(collection(db, 'posts'), {
      uid: currentUser.uid,
      name: currentUser.displayName,
      photoURL: currentUser.photoURL,
      caption: captionInput.value,
      mediaURL: url,
      mediaType: file.type.startsWith('video') ? 'video' : 'image',
      likes: [],
      comments: [],
      createdAt: serverTimestamp()
    });
    uploadStatus.textContent = 'Upload complete ✓';
  });
};

onSnapshot(collection(db, 'posts'), snapshot => {
  postsEl.innerHTML = '';
  snapshot.forEach(doc => {
    const p = doc.data();
    const div = document.createElement('div');
    div.className = 'post';
    div.innerHTML = `<h4>${p.name}</h4><p>${p.caption||''}</p>` +
      (p.mediaType==='video'?`<video src="${p.mediaURL}" controls></video>`:`<img src="${p.mediaURL}" style="max-width:100%">`);
    postsEl.appendChild(div);
  });
});
