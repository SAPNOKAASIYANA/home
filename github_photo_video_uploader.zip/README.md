# 📸 Gmail Auth Photo/Video Uploader (for GitHub Pages)

यह प्रोजेक्ट आपको एक वेबसाइट देता है जहाँ यूजर Google से लॉगिन करके अपनी फोटो और वीडियो अपलोड कर सकता है।
दूसरे यूजर्स उन्हें देख सकते हैं, लाइक और कमेंट कर सकते हैं।

## 🔧 Setup Steps
1. [Firebase Console](https://console.firebase.google.com/) पर नया प्रोजेक्ट बनाएं।
2. Authentication → Google Sign-In enable करें।
3. Firestore Database और Storage enable करें।
4. `app.js` में Firebase config को अपने प्रोजेक्ट के अनुसार भरें।
5. इस repo को GitHub पर अपलोड करें और GitHub Pages enable करें।

## 📂 Files
- `index.html` → UI और Firebase JS इम्पोर्ट
- `style.css` → बेसिक स्टाइल
- `app.js` → Firebase logic
- `README.md` → निर्देश

## 🚀 Run on GitHub Pages
1. Code अपलोड करें → Settings → Pages → Branch चुनें → Save करें।
2. कुछ सेकंड बाद आपकी वेबसाइट GitHub Pages पर लाइव होगी!
